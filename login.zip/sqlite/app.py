from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('scam_reporting.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=('GET', 'POST'))
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        conn = get_db_connection()
        conn.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                     (username, email, password))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('register.html')

@app.route('/report', methods=('GET', 'POST'))
def report():
    if request.method == 'POST':
        user_id = 1  # In a real application, this should be dynamic
        scam_type = request.form['scam_type']
        report_date = request.form['report_date']
        details = request.form['details']

        conn = get_db_connection()
        conn.execute('INSERT INTO scam_reports (user_id, scam_type, report_date, details) VALUES (?, ?, ?, ?)',
                     (user_id, scam_type, report_date, details))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('report.html')

@app.route('/reports')
def reports():
    conn = get_db_connection()
    reports = conn.execute('SELECT * FROM scam_reports').fetchall()
    conn.close()
    return render_template('reports.html', reports=reports)

if __name__ == '__main__':
    app.run(debug=True)
